# Daily Hisab (installable app) - upload to its OWN new GitHub repository

Do NOT upload these to the POS repository.

Files:
    index.html                the app
    daily-hisab.webmanifest   app name, colours, icons
    daily-hisab-sw.js         offline support (only touches Daily Hisab files)
    dh-icons/                 5 icon png files
    .nojekyll                 keeps GitHub Pages simple

Steps: New repository (name: daily-hisab, Public) -> Upload all files -> Settings -> Pages ->
Deploy from a branch -> main / root -> Save. App address:
https://YOUR-USERNAME.github.io/daily-hisab/

Update later: replace index.html, then change 'v2' to 'v3' (and so on) in
daily-hisab-sw.js and commit.
